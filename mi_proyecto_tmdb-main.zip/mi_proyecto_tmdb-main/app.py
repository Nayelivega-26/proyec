import requests
from flask import Flask, render_template, request

app = Flask(__name__)

API_KEY = "466fae31b33067ad820239b8d2e7d2e2"
BASE_URL = "https://api.themoviedb.org/3"

def buscar_peliculas_similares(nombre_pelicula):
    url_buscar = f"{BASE_URL}/search/movie"
    params = {
        "api_key": API_KEY,
        "language": "es-ES",
        "query": nombre_pelicula,
        "page": 1
    }
    respuesta = requests.get(url_buscar, params=params)
    peliculas = []
    if respuesta.status_code == 200:
        resultados = respuesta.json().get('results', [])
        for peli in resultados[:5]:
            peliculas.append({
                "title": peli['title'],
                "overview": peli.get('overview', 'Sin descripción.'),
                "imagen": f"https://image.tmdb.org/t/p/w500{peli['poster_path']}" if peli.get('poster_path') else ''
            })
    return peliculas

def obtener_recomendaciones(id_pelicula, cantidad=5):
    url_recomendaciones = f"{BASE_URL}/movie/{id_pelicula}/recommendations"
    params = {
        "api_key": API_KEY,
        "language": "es-ES"
    }
    respuesta = requests.get(url_recomendaciones, params=params)
    recomendaciones = []
    if respuesta.status_code == 200:
        resultados = respuesta.json().get('results', [])[:cantidad]
        for peli in resultados:
            recomendaciones.append({
                "title": peli['title'],
                "overview": peli.get('overview', 'Sin descripción.'),
                "imagen": f"https://image.tmdb.org/t/p/w500{peli['poster_path']}" if peli.get('poster_path') else ''
            })
    return recomendaciones

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/recomendar', methods=['POST'])
def recomendar():
    pelicula_input = request.form.get('pelicula')
    if not pelicula_input:
        return render_template('index.html', mensaje="Por favor, escribe el nombre de una película.")

    similares = buscar_peliculas_similares(pelicula_input)

    id_pelicula = None
    if similares:
        url_buscar_id = f"{BASE_URL}/search/movie"
        params = {
            "api_key": API_KEY,
            "language": "es-ES",
            "query": pelicula_input
        }
        respuesta = requests.get(url_buscar_id, params=params)
        if respuesta.status_code == 200:
            resultados = respuesta.json().get('results', [])
            if resultados:
                id_pelicula = resultados[0]['id']

    recomendaciones = obtener_recomendaciones(id_pelicula) if id_pelicula else []

    titulos = set()
    peliculas_finales = []
    for peli in similares + recomendaciones:
        if peli['title'] not in titulos:
            peliculas_finales.append(peli)
            titulos.add(peli['title'])

    if not peliculas_finales:
        return render_template('index.html', mensaje="No se encontraron recomendaciones para esta película.")

    return render_template('index.html', recomendaciones=peliculas_finales, mensaje=None)

# 🔥 Esta parte es esencial para ejecutar el servidor
if __name__ == '__main__':
    app.run(debug=True)
